// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("soname check"); }
int main(){
  announce();
  return lionss_run_workload("soname-check");
}
