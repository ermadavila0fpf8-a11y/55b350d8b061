// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("pkg config check\n", stdout);
  return lionss_run_workload("pkg-config-check");
}
