// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("meson build"); }
int main(){
  announce();
  return lionss_run_workload("meson-build");
}
