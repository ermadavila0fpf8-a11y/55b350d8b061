// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("gcc 14"); }
int main(){
  announce();
  return lionss_run_workload("gcc-14");
}
